# landmines_detection > 2024-07-25 9:25pm
https://universe.roboflow.com/xamurani/landmines_detection

Provided by a Roboflow user
License: CC BY 4.0

